/* ═══════════════════════════════════════════════
   ABDALLA KEYNAN — CORE SCRIPT
   ═══════════════════════════════════════════════ */

'use strict';

/* ── Storage Helpers ── */
const DB = {
  get: k => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
  set: (k,v) => localStorage.setItem(k, JSON.stringify(v)),
  del: k => localStorage.removeItem(k),
  users:    () => DB.get('ak_users')    || [],
  books:    () => DB.get('ak_books')    || [],
  session:  () => DB.get('ak_session'),
  setUsers: v  => DB.set('ak_users', v),
  setBooks: v  => DB.set('ak_books', v),
  setSession: v => DB.set('ak_session', v),
  clearSession: () => DB.del('ak_session'),
};

/* ── Toast Notifications ── */
function toast(msg, type = 'info', duration = 3500) {
  const icons = { success:'ri-checkbox-circle-line', error:'ri-error-warning-line',
                  info:'ri-information-line', warn:'ri-alert-line' };
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<i class="${icons[type] || icons.info}"></i><span>${msg}</span>`;
  container.appendChild(el);
  setTimeout(() => {
    el.classList.add('fade-out');
    setTimeout(() => el.remove(), 300);
  }, duration);
}

/* ── Loading Screen ── */
function initLoader(delay = 1500) {
  const screen = document.getElementById('loading-screen');
  if (!screen) return;
  setTimeout(() => {
    screen.classList.add('hidden');
    setTimeout(() => screen.remove(), 600);
  }, delay);
}

/* ── Auth Guards ── */
function requireAuth() {
  const s = DB.session();
  if (!s) { window.location.href = 'login.html'; return null; }
  const users = DB.users();
  const user = users.find(u => u.id === s.userId);
  if (!user) { DB.clearSession(); window.location.href = 'login.html'; return null; }
  return user;
}

function redirectIfAuthed() {
  if (DB.session()) window.location.href = 'dashboard.html';
}

function getCurrentUser() {
  const s = DB.session();
  if (!s) return null;
  return DB.users().find(u => u.id === s.userId) || null;
}

function logout() {
  DB.clearSession();
  toast('Logged out successfully.', 'info', 1500);
  setTimeout(() => window.location.href = 'index.html', 800);
}

/* ── Validation Helpers ── */
const Validators = {
  email: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
  phone: v => /^\+?[\d\s\-]{7,15}$/.test(v),
  password: v => v.length >= 6,
  required: v => v.trim().length > 0,
};

function attachInputValidation(inputEl, rules) {
  const group = inputEl.closest('.form-group');
  const errEl = group?.querySelector('.field-error');
  const check = () => {
    for (const [rule, msg] of rules) {
      if (!Validators[rule]?.(inputEl.value)) {
        inputEl.classList.remove('valid'); inputEl.classList.add('error');
        if (errEl) { errEl.textContent = msg; errEl.classList.add('show'); }
        return false;
      }
    }
    inputEl.classList.remove('error'); inputEl.classList.add('valid');
    if (errEl) errEl.classList.remove('show');
    return true;
  };
  inputEl.addEventListener('blur', check);
  return check;
}

/* ── ID Generator ── */
function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2,7); }

/* ── Time Formatter ── */
function timeAgo(ts) {
  const diff = Date.now() - ts;
  const m = Math.floor(diff/60000);
  if (m < 1)  return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m/60);
  if (h < 24) return `${h}h ago`;
  return new Date(ts).toLocaleDateString();
}

/* ── Navbar Active State ── */
function setNavActive() {
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.navbar-links a').forEach(a => {
    if (a.getAttribute('href') === page) a.classList.add('active-link');
  });
}

/* ── Category Colors ── */
const CAT_COLORS = {
  'Science':     '#3b82f6',
  'Mathematics': '#8b5cf6',
  'History':     '#f59e0b',
  'Technology':  '#10b981',
  'Literature':  '#ec4899',
  'Engineering': '#14b8a6',
  'Medicine':    '#ef4444',
  'Arts':        '#f97316',
  'Business':    '#6366f1',
  'Other':       '#64748b',
};

function catBadge(cat) {
  const c = CAT_COLORS[cat] || CAT_COLORS['Other'];
  return `<span class="badge" style="background:${c}22;color:${c};border-color:${c}44">${cat}</span>`;
}

/* ── File to Base64 ── */
function fileToBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = e => res(e.target.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

/* ── Init on DOM ready ── */
document.addEventListener('DOMContentLoaded', () => {
  initLoader();
  setNavActive();
});
